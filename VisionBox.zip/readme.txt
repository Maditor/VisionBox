file ocr-translate-config.json được sinh ra sau khi dung tool là file chứa API KEY.

KHÔNG chia sẻ file ocr-translate-config.json cho người khác nếu không muốn mất các lượt dùng và token.

chúc mọi người làm việc vui vẻ!!

